// 5 Types
const URl = "https://teachablemachine.withgoogle.com/models/BBLEnW2ph/";

// 4 Types
// const URL = "https://teachablemachine.withgoogle.com/models/6Y0ZOWYcC/";

// Old Model
// const URL = "https://teachablemachine.withgoogle.com/models/uFboKu8oZ/";

export const ModelURL = URL;
